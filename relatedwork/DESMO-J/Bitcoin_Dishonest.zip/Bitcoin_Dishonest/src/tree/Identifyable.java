package tree;

public interface Identifyable {
	
	public long getID();

}
