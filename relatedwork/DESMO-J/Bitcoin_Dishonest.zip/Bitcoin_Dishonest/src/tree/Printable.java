package tree;

public interface Printable {
	
	public String print();
	
	public String printShort();

}
